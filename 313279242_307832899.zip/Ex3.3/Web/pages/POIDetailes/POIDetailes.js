

angular.module("myApp")
.controller("POIDetailes", function ($window,$rootScope,$scope, $http) {

    $scope.refresh=function(){

            $http.get('http://127.0.0.1:3000/POIs/getPOIByName/'+$window.sessionStorage.getItem(1))
    
    .then(function(response){ 
     $scope.name=$window.sessionStorage.getItem(1);              
    $scope.view=response.data.POIView;
    $scope.descript=response.data.Description;
    var r=response.data.POIRank;
    r=r/5;
    r=r*100;


    $scope.rank=r+"%";
    $scope.review1=response.data.POIReview1;
    $scope.review2=response.data.POIReview2;

})

    }

    $scope.submitrank = function(){
       
        var Rank_Json= {POI: $window.sessionStorage.getItem(1), POIRank:$scope.rankinput}
        $http.put('http://127.0.0.1:3000/POIs/addPOIRank/', Rank_Json)
        .then(function(response){
            alert("Saved succsesfuly")
            $scope.error="";   
        })
        .catch(function(err){
            $scope.error=err.data.err;
        })

    }


    $scope.SendReview=function(){
        
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();    
        today = dd + '/' + mm + '/' + yyyy; 
        var rev = today + " " +$scope.reviewinput;

        var Review_Json= {POI: $window.sessionStorage.getItem(1), POIReview:rev}
        $http.put('http://127.0.0.1:3000/POIs/addPOIReview/', Review_Json)
        .then(function(response){     
       alert("Saved succsesfuly "+ $scope.reviewinput)
        })
        .catch(function(err){
            $scope.error=err.data.err;
        })


    }

})





