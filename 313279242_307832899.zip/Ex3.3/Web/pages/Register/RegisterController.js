
angular.module("myApp")
.controller("RegisterController", function ($rootScope,$location,$scope,$http) {
    
    $scope.submit = function(){        
        interests=[];
        if($scope.food){
            interests.push("food");
        }
        if($scope.Shopping){
            interests.push("Shopping");
        }
        if($scope.attractions){
            interests.push("attractions");
        }
        if($scope.nightclubs){
            interests.push("night clubs");
        }

            if(interests.length<2){
                $scope.answer="Register failed Please Try again The error is : you need to choose at least 2 interests  ";
                return;
            }
            if($scope.ques1==$scope.ques2){
                $scope.answer="Register failed Please Try again The error is : you need to choose 2 different questions  ";
                return;

            }

        const user = {
            username: $scope.uname,
            password: $scope.password,
            FirstName: $scope.FirstName,
            LastName: $scope.LastName,
            City: $scope.City,
            Country: $scope.Country,
            Email:$scope.Email,
            Interests: interests,
            question1: $scope.ques1,
            answer1: $scope.ans1,
            question2: $scope.ques2,
            answer2: $scope.ans2,

        };


        $http.post('http://localhost:3000/users/Registration/JsonRegister',user)
        .then(function(response){
        alert("Register Successfull")
         $location.path('/Home');

        })
        .catch(function (err) {

            $scope.answer="Register failed Please Try again The error is : "+ err.data.err;
  
        });
    

    };


    $scope.names = ["Australia", "Bolivia", "China", "Denemark", "Israel", "Latvia", "Monaco", "August", "Norway","Panama","Switzerland","USA"];
    $scope.ints=["food", "Shopping", "attractions", "night clubs"];
    $scope.q1=["Whats your mothers name?", "What is your fathers name?", "where do you live?", "what was your elementary school?"]
    $scope.q2=["Whats your mothers name?", "What is your fathers name?", "where do you live?", "what was your elementary school?"]
});