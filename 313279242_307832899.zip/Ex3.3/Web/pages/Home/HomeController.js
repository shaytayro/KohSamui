angular.module("myApp")

.controller("HomeController", function ($location,$window,$rootScope,$scope,$http) {
    // button click count
    $scope.star=[];
    $scope.star.push("https://cdn0.iconfinder.com/data/icons/bookmarks-tags-8/24/tag_favorite_star_Add_Bookmark-512.png");
    $scope.star.push("https://cdn0.iconfinder.com/data/icons/bookmarks-tags-8/24/tag_favorite_star_Add_Bookmark-512.png");
    $scope.star.push("https://cdn0.iconfinder.com/data/icons/bookmarks-tags-8/24/tag_favorite_star_Add_Bookmark-512.png");
    $scope.reg=true;
    
    $scope.refresh = function() {
    
        self = this;
    $http.get('http://127.0.0.1:3000/POIs/getRandomPOI')
    .then(function(response){
        $scope.POI1=response.data.P1;
        $scope.POI2=response.data.P2;
        $scope.POI3=response.data.P3;
        loadImage(response.data.P1,response.data.P2,response.data.P3);

    })  
    .catch(function (err) {
        $scope.POI1=err;

    });


    
    };


    $scope.reg = function(){
        console.log($rootScope.token);
        if($rootScope.token==""){
        $location.path('/Register');
    }
    else{
        alert("You already have a account");
        return;
    }
    }

        $scope.disconnect=function(){

            if( $rootScope.token==""){
                alert("In order to disconnect you need to connect first");
                return;
            }
            else{
               

            if( confirm("Are you sure you want to disconnect?")){
            $rootScope.token = "";
            $rootScope.hello="hello guest";
            $rootScope.count=0;
            $rootScope.loggedIn = false;

        }
        else{
            return;
        }
        }


        }



    $scope.addfav=function(POI1,index){
        
        if($rootScope.token==""){
            alert("You must to Login In order to add to favorite");
            return;
        }

        if($scope.star[index]=="https://www.pngrepo.com/download/221104/star-favorite.png"){
            
        $rootScope.removefavorite(POI1);
        $scope.star[index]="https://cdn0.iconfinder.com/data/icons/bookmarks-tags-8/24/tag_favorite_star_Add_Bookmark-512.png";
        }


        else{
            $rootScope.addtofavorite(POI1);
            $scope.star[index]="https://www.pngrepo.com/download/221104/star-favorite.png";
        }

    }

function loadImage(p1,p2,p3){

    $http.get('http://127.0.0.1:3000/POIs/GetPictureLink/'+p1)
    .then(function(response){
        $scope.ImgPOI1=response.data.Link;
    })  
    .catch(function (err) {
        $scope.ImgPOI1=err;

    });

    $http.get('http://127.0.0.1:3000/POIs/GetPictureLink/'+p2)
    .then(function(response){
        $scope.ImgPOI2=response.data.Link;
    })  
    .catch(function (err) {
        $scope.ImgPOI2=err;

    });


    $http.get('http://127.0.0.1:3000/POIs/GetPictureLink/'+p3)
    .then(function(response){
        $scope.ImgPOI3=response.data.Link;
    })  
    .catch(function (err) {
        $scope.ImgPOI3=err;

    });





}

$scope.opendetailes=function(POI1){

     $window.sessionStorage.setItem(1,POI1);   
     $window.open
    ('/index.html#!/POIDetailes', 
    'C-Sharpcorner', 
    'toolbar=no,scrollbars=no,resizable=no,top=100,left=500,width=700,height=800    ');

}


});



    


