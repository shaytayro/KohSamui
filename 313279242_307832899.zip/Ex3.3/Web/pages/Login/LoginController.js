
angular.module("myApp")
.controller("LoginController", function ($rootScope,$scope,$http,$location) {


$scope.Login=function(){

    const user={
        username: $scope.uname ,
        password:  $scope.password
    }

    $http.post('http://localhost:3000/users/Login/JsonLogin',user)
    .then(function(response){
        $rootScope.token = response.data;
        console.log($rootScope.token);
        $rootScope.loggedIn = true;
        $rootScope.hello="hello "+$scope.uname;
        $http.get('http://127.0.0.1:3000/users/getNumberOfSavedFavoritePOI',{ headers:{'x-auth-token': $rootScope.token}})
        .then(function(response2){
            $rootScope.count=response2.data.message;})       
        $location.path('/ConnectedUser');

    })
    .catch(function (err) {
        $scope.answer=err.data.err;

    });





}

});