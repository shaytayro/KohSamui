
Wellcome to our website about Koh Samui - the most tourist destination in Thailand !!!
----
----
The website created by Shay Tayro & Eti Reznik 

In order to start use you need to load the server via localhost port 3000.

At home page you can login or register.

you can login via this users :

username : a 
password : a

username : shay
password : 12345

username : eti
password : 12345

username : gggg
password : ggggg

username : dany
password : dany1

After login you can enjoy our services create favorite list of poi which display in favorite page , search for poi At POI page and more. 

Have fun !!!


